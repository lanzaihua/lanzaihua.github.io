# AI Tells 目录（Anti-Tell Catalog）—— SKILL.md §9 外置参考

> 触发时机：生成 landing page / portfolio 前（作为反模式速查）+ Pre-Flight Check 时（逐条对照）。
> S4 Design Engineering 中的内联规则是操作指令；此处是完整的 AI slop 特征目录（含 S9.F Production-Test Tells 和 S9.G Em-Dash Ban）。
## 9. AI TELLS (Forbidden Patterns)

Avoid these signatures unless the brief explicitly asks for them.

### 9.A Visual & CSS
* **NO neon / outer glows** by default — inner borders or subtle tinted shadows.
* **NO pure black (`#000000`)** — off-black, zinc-950, charcoal.
* **NO oversaturated accents** — desaturate to blend with neutrals.
* **NO excessive gradient text** on large headers.
* **NO custom mouse cursors** — outdated, accessibility- and perf-hostile.

### 9.B Typography
* **AVOID Inter as default** (SKILL.md §4.1; override path exists).
* **NO oversized H1s that just scream** — control hierarchy with weight + color, not raw scale.
* **Serif for editorial / luxury / publication only**, never dashboards.

### 9.C Layout & Spacing
* Mathematically consistent padding/margins; no awkward floating gaps.
* **NO 3-column equal feature cards** — use 2-column zig-zag, asymmetric grid, scroll-pinned, or horizontal-scroll alternatives.

### 9.D Content & Data ("Jane Doe" Effect)
* **NO generic names** ("John Doe", "Sarah Chan") → creative, realistic, locale-appropriate.
* **NO generic avatars** (SVG "egg", Lucide user icons) → believable photo placeholders or specific styling.
* **NO fake-perfect numbers** (`99.99%`, `50%`, `1234567`) → organic messy data (`47.2%`, `+1 (312) 847-1928`).
* **NO startup-slop brand names** ("Acme", "Nexus", "SmartFlow") → contextual names that sound real.
* **NO filler verbs** ("Elevate", "Seamless", "Unleash", "Next-Gen", "Revolutionize") → concrete verbs only.

### 9.E External Resources & Components
* **NO hand-rolled SVG icons** — Phosphor / HugeIcons / Radix / Tabler; Lucide on explicit request only. Decorative SVGs strongly discouraged (4.8).
* **NO div-based fake screenshots** — full ban in 9.F.
* **NO broken Unsplash links** — `https://picsum.photos/seed/{descriptive-string}/{w}/{h}`, generated placeholders, or actual assets.
* **shadcn/ui** allowed but NEVER in default state — customize radii, colors, shadows, typography to the project aesthetic. Code ships visually clean and meticulously refined.

### 9.F Production-Test Tells (banned outright)

Real LLM-test signatures of "trying to look designed." Hard bans unless the brief explicitly calls for one.

**Hero & top-of-page**
* **NO version labels in the hero** (`V0.6`, `BETA`, `INVITE-ONLY PREVIEW`, `EARLY ACCESS`, `ALPHA`) — only for briefs explicitly about launch / preview status.
* **NO "Brand · No. 01"-style sub-eyebrows** ("Marrow · No. 01 · The 6-quart"). Skip.

**Section numbering & micro-labels**
* **NO section-number eyebrows** (`00 / INDEX`, `001 · Capabilities`, `06 · how it works`) — eyebrows name the topic in plain language, never enumerate.
* **NO `01 / 4` pagination on images or bento tiles.**
* **NO `Scroll · 001 Capabilities`-style scroll cues** — a simple arrow or "Scroll" is enough, no section-number prefix.
* **NO "Index of Work, 2018-2026"-style range labels** as eyebrows — say what the section is.

**Separators & dots**
* **The middle-dot (`·`) is rationed: max 1 per line** in metadata strips — never the default separator for everything; prefer line breaks, hairlines, or columns.
* **NO decorative colored status dots** on lists/nav/badges — acceptable ONLY for real semantic state (server status, availability flag), sparingly (this ban is absolute: repeated in Locale section below intentionally).

**Em-dashes & typography flourishes**
* **Em-dash (`—`): completely banned everywhere** — the full non-negotiable rule is 9.G below.
* **NO `<br>`-broken-and-italicized headlines** as a default "design move" ("for thirty\<br\>*years.*") — headlines read naturally first.
* **NO vertical rotated text** ("INDEX OF WORK 2018-2026" at 90°) — agency cliché; only for explicit agency / Awwwards / experimental briefs serving real composition.
* **NO crosshair / hairline grid lines as decoration** — only when they organize real content.

**Fake product previews**
* **NO div-based fake product UI anywhere (hero worst)** — fake task lists / terminals / dashboards from styled divs is the #1 LLM-design Tell. Real screenshot, generated image, real mini component preview, or none.
* **NO fake version footers inside fake screenshots** ("v0.6.2-rc.1", "last sync 4s ago · main").

**Marketing-copy Tells**
* **NO "Quietly in use at" / "Quietly trusted by"** — "Trusted by", "Used at", "Customers include", or no heading.
* **NO poetic section labels** ("From the field", "Field notes", "On our desks", "Loose plates") — plain functional labels ("Testimonials", "Latest writing") or none.
* **NO mock-humble industry-references in body copy.**
* **NO micro-meta-sentences under eyebrows** — Eyebrow + Headline + Body is enough.
* **NO generic step labels** ("Stage 1/2/3", "Phase 01/02/03", "Pass One/Two/Three") — the step content IS the label; if progression needs showing, use the verb-noun directly ("Install", "Configure", "Ship").

**Pills, labels and version stamps**
* **NO pills/labels/tags overlaid on images** (`Brand · 02`, `PLATE · BRAND`) — image speaks alone or caption below (outside the image).
* **NO photo-credit captions as decoration** (`Field study no. 12 · Ines Caetano`, `Plate 03 · House archive`) — credit only a real photographer of a real photo; otherwise functional one-liner or none.
* **NO version footers on marketing pages** (`v1.4.2`, `Build 0048`) — devtool fixtures, not landing-page content.
* **NO "Reservation 412 of 800" live-stock counters** — only for explicit limited-run waitlists with real data.

**Decoration text strips**
* **NO decoration text strip at hero bottom** (`BRAND. MOTION. SPATIAL.`, `TYPE / FORM / MOTION`, `ESTD. 2018 · LISBON`) — only when it carries real navigable links or real status info.
* **NO floating top-right sub-text in section headings** — put sub-text under the headline or build a clean aligned 2-column header; a tiny corner paragraph is the Tell.

**Lists, dividers and scoring**
* **NO `border-t` + `border-b` on every row** of long lists / spec tables — pick one border, use sparsely (alternatives in 4.9).
* **NO scoring/progress bars with filled background tracks** — number + small icon, or tiny inline bar WITHOUT a track.

**Locale, time, scroll cues**
* **Locale / city / time / weather strips banned for 99% of briefs** ("Lisbon, working with founders", "Lisbon 14:23 · 18°C") — allowed ONLY for globally-distributed-studio / travel / physical-venue briefs; a single footer contact address is fine, atmospheric strips are not.
* **Scroll cues banned** (`Scroll`, `↓ scroll`, "Scroll to explore", mouse-wheel icons) — if they have not scrolled yet they are looking at the hero; they know what scroll is.
* **ZERO decorative status dots by default** — same rule as above (real semantic state only, max one per page section).

### 9.G EM-DASH BAN (the single most-violated Tell)

**Em-dash (`—`) is COMPLETELY banned — zero allowance.** No "limited use", no "natural language frequency", no "body copy is fine". Banned in headlines, eyebrows, labels, pills, buttons, captions, nav, body copy, quotes, attribution, alt text. Replacements:
* Headlines/labels → period, comma, line break, or hairline.
* Body copy → restructure: two sentences, comma, parentheses, or colon.
* Quote attribution → spaced hyphen (` - `) or line break + smaller name.
* En-dash (`–`) as separator is equally banned — date / number ranges (`2018-2026`, `€40-80k`) use a plain hyphen.

Permitted dash characters: regular hyphen `-` (compound words, ranges, markup dividers) and the math minus (`-5°C`). A single visible `—` or `–` fails the Pre-Flight Check and must be rewritten. Binary rule: zero (historically ignored when phrased as "use sparingly").

---


