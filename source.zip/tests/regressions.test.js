'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const ROOT = path.join(__dirname, '..');
const KEY = 'sanke-cuotiben-v1';
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
function runtime(raw, denied = false) {
  const values = new Map(raw === undefined ? [] : [[KEY, raw]]);
  const subjects = JSON.parse(read('src/data/seed.json')).subjects;
  const ctx = { console, Date, Set, Map, Intl, URL, Blob, setTimeout: () => 0, clearTimeout() {},
    location: {hostname: 'localhost', protocol: 'https:', hash: '', pathname: '/', search: ''},
    localStorage: {getItem(k) {if(denied) throw Error('denied');return values.get(k) ?? null;},setItem(k,v) {if(denied) throw Error('denied'); values.set(k,v);}},
    window: {addEventListener() {}, __SEED__: {subjects}, __BANKS__: {}, __PAGES__: true},
    document: {addEventListener() {}, querySelector(){return null;},querySelectorAll(){return [];}} };
  vm.createContext(ctx);
  vm.runInContext(read('src/js/00-chapters.js') + '\n' + read('src/js/00-core.js'), ctx);
  ctx.toast = () => {};
  return {ctx, values, run(file) {vm.runInContext(read('src/js/'+file), ctx);}};
}
function savedEntry(id='keep') {return {id,code:'A-001',date:'2026-01-01',summary:'保留错题',stars:2,blocks:[],variants:[],points:[],errorTypes:[],status:'unmastered'};}
function savedState() { return {entries: {gaodai:[savedEntry()],shufen:[],jieji:[],xijing:[]},prefs:{theme:'auto'}}; }
test('legacy state without clearEpoch retains entries through migration and reload', () => {
  const r = runtime(JSON.stringify(savedState()));
  assert.equal(r.ctx.state.entries.gaodai[0].id,'keep');
  assert.equal(r.ctx.persistLocal(),true);
  assert.equal(runtime(r.values.get(KEY)).ctx.state.entries.gaodai[0].id,'keep');
});
test('corrupt and invalid-shaped state is preserved instead of overwritten', () => {
  for(const raw of ['{broken',JSON.stringify({entries: []}),JSON.stringify({entries:{gaodai:[null]}})]) {
    const r = runtime(raw); assert.equal(r.ctx.storageRecoveryBlocked,true);
    assert.equal(r.ctx.persistLocal(),false); assert.equal(r.values.get(KEY),raw);
  }
});
test('blocked browser storage does not abort application boot', () => {
  const r = runtime(undefined,true); assert.equal(r.ctx.sync.token,''); assert.equal(r.ctx.persistLocal(),false);
});
test('malformed entry hash does not abort route parsing', () => {
  const r=runtime(); vm.runInContext(read('src/js/90-init.js').split('function updateHash()')[0],r.ctx);
  r.ctx.location.hash='#/gaodai/entries?e=%E0%A4%A';
  assert.doesNotThrow(()=>r.ctx.parseHash()); assert.equal(r.ctx.state.activeView,'entries');
});
test('AI choices require distinct A-D keys and a correct key present in options',()=>{
  const r=runtime();r.run('59-exam.js');r.ctx.mathifyPlainText=s=>s;r.ctx.smartChapterFor=()=>'';
  const base={question:'选择正确项',answer:'A',standardSolution:'解：A',type:'choice',correct:'A',options:['A','B','C','D'].map(key=>({key,text:key}))};
  assert.ok(r.ctx.finalNormalizeAiQuestion(base,0,'gaodai'));
  assert.equal(r.ctx.finalNormalizeAiQuestion({...base,correct:'Z'},0,'gaodai'),null);
  assert.equal(r.ctx.finalNormalizeAiQuestion({...base,options:[base.options[0],base.options[0],...base.options.slice(2)]},0,'gaodai'),null);
  r.run('60-paper-edit.js');r.ctx.finalSubject=()=>'gaodai';r.ctx.subjectOf=sid=>r.ctx.SUBJ_BY_ID[sid];
  assert.equal(r.ctx.finalPaperNormalizeAiQuestions([{...base,correct:'Z'}],{}).length,0);
  assert.equal(r.ctx.finalPaperNormalizeAiQuestions([base],{}).length,1);
});
test('Markdown strips executable tags, URL schemes and attributes; preserves Markdown and math',()=>{
  const {parseHTML}=require('linkedom'); const {document}=parseHTML('<!doctype html><html><body></body></html>');
  const r=runtime();r.ctx.document=document;r.ctx.window.marked=r.ctx.marked=require('../src/vendor/marked.umd.js');
  vm.runInContext(read('src/vendor/temml.min.js'),r.ctx);r.ctx.window.temml=r.ctx.temml;r.run('10-markdown.js');
  for(const src of ['[danger](javascript:alert%281%29)','<a href="jav&#x61;script:alert(1)">danger</a>','<a href="java&#10;script:alert(1)">danger</a>','<img src=x onerror="alert(1)">','<svg><a href="javascript:alert(1)">x</a></svg>','<iframe srcdoc="<script>alert(1)</script>"></iframe>','<object data="data:text/html,bad"></object>','<img src="data:image/svg+xml;base64,AAAA">']) {
    const html=r.ctx.renderMarkdown(src);const e=document.createElement('div');e.innerHTML=html;
    assert.equal(e.querySelector('script,iframe,object,embed,svg,form,style'),null,html);
    for(const el of e.querySelectorAll('*')) for(const a of el.attributes) {
      assert.ok(!/^on/i.test(a.name),html);
      if(['href','src'].includes(a.name)) assert.ok(!/^(javascript|vbscript|data:text|data:image\/svg)/i.test(a.value.replace(/\s/g,'')),html);
    }
  }
  const normal=r.ctx.renderMarkdown('**粗体** [文档](https://example.com)\n\n$x^2+1$');
  assert.match(normal,/<strong>/);assert.match(normal,/https:\/\/example.com/);assert.match(normal,/<math/);
  assert.match(r.ctx.renderMarkdown('![手写](data:image/png;base64,AAAA)'),/data:image\/png;base64,AAAA/);
  const malformed = '故 H 是对称阵。 （2）由 H^T = H 可得 HH^T = H^2。再由 X^T X = 1 及矩阵乘法的结合律，得 H^2=(E-2XX^{\\mathrm T})^2=E-4XX^{\\mathrm T}+4(XX^{\\mathrm T})(XX^{\\mathrm T})$ =E-4XX^{\\mathrm T}+4X(X^{\\mathrm T}X)X^{\\mathrm T} =E-4XX^{\\mathrm T}+4XX^{\\mathrm T}=E. 因此 HH^T = E。证毕。';
  const malformedHtml = r.ctx.renderMarkdown(malformed);
  const malformedDoc = document.createElement('div'); malformedDoc.innerHTML = malformedHtml;
  assert.equal(malformedDoc.querySelectorAll('.math-raw').length, 0, malformedHtml);
  assert.equal(malformedDoc.textContent.includes('$'), false, malformedHtml);
  assert.equal(malformedDoc.textContent.includes('\\mathrm'), false, malformedHtml);
  assert.ok(malformedDoc.querySelectorAll('math').length >= 4, malformedHtml);
  assert.match(r.ctx.renderMarkdown('由 $H^T=H$ 与 $X^TX=1$ 得 $H^2=E$。'), /<math/);
});
test('sync conflict preserves local edits and revision',async()=>{
  const r=runtime();r.run('05-sync.js');r.ctx.sync.available=true;r.ctx.renderSyncStatus=()=>{};
  r.ctx.state.rev=7;r.ctx.state.updatedAt='2026-01-01T00:00:00Z';
  r.ctx.fetch=async()=>({status:409,json:async()=>({rev:9,state:{...savedState(),updatedAt:'2026-12-01T00:00:00Z'}})});
  await r.ctx.pushSync(false);assert.equal(r.ctx.state.rev,7);assert.equal(r.ctx.sync.mode,'conflict');
});
test('edits made while pushing retain their timestamp and schedule another push',async()=>{
  const r=runtime();r.run('05-sync.js');r.ctx.sync.available=true;r.ctx.renderSyncStatus=()=>{};
  r.ctx.state.updatedAt='2026-01-01T00:00:00Z';let scheduled=false;
  r.ctx.schedulePush=()=>{scheduled=true;};
  r.ctx.fetch=async()=>{r.ctx.state.updatedAt='2026-01-01T00:00:02Z';return {ok:true,status:200,json:async()=>({rev:8,updatedAt:'2026-01-01T00:00:01Z'})};};
  await r.ctx.pushSync(false);assert.equal(r.ctx.state.updatedAt,'2026-01-01T00:00:02Z');assert.equal(scheduled,true);
});
test('all four complete skill packs are usable without author home directories',()=>{
  const {buildSkillPacks}=require('../tools/build-skill-packs');const packs=buildSkillPacks();
  const {loadSkillBundle}=require('../skills');
  for(const sid of ['gaodai','shufen','jieji','xijing']) {assert.ok(packs.subjects[sid].chapters.every(c=>c.text));assert.ok(loadSkillBundle(sid,'极限', '').materials[0].text);}
});
test('filling blanks survive typography normalization and rendering',()=>{
  const {document}=require('linkedom').parseHTML('<html></html>');const r=runtime();r.ctx.document=document;
  r.ctx.window.marked=r.ctx.marked=require('../src/vendor/marked.umd.js');r.run('10-markdown.js');
  assert.match(r.ctx.renderMarkdown('答案是____。'),/____/);
});
test('paper preview includes all choice options and material import preserves metadata',()=>{
  const r=runtime(); r.ctx.document.addEventListener=()=>{}; r.run('58-final.js');r.run('60-paper-edit.js');
  r.ctx.renderMarkdown=s=>s;r.ctx.stripTypePrefix=s=>s;
  const html=r.ctx.finalPaperItemHtml({options:[{key:'A',text:'第一项'},{key:'B',text:'第二项'}]},0,{});
  assert.match(html,/第一项/);assert.match(html,/第二项/);
  const paper={items:[]};const m={key:'bank:q',id:'q',questionType:'choice',options:[{key:'A',text:'保留项'}],correct:'A',standardSolution:'完整解答',points:['要点']};
  r.ctx.finalActivePaper=()=>paper;r.ctx.finalSubject=()=>'gaodai';r.ctx.document={querySelector:()=>({value:'bank:q'})};
  r.ctx.finalMaterialsForChapters=()=>[m];r.ctx.markDirty=()=>{};r.ctx.render=()=>{};
  r.ctx.finalPaperImportMaterial();assert.equal(paper.items[0].options[0].text,'保留项');assert.equal(paper.items[0].standardSolution,'完整解答');
});
test('local edit counter is independent from server optimistic-lock revision',async()=>{
  const r=runtime();r.run('05-sync.js');r.ctx.sync.available=true;r.ctx.sync.baseRev=2;r.ctx.state.rev=17;r.ctx.renderSyncStatus=()=>{};let sent;
  r.ctx.fetch=async(url,opts)=>{sent=JSON.parse(opts.body);return {ok:true,status:200,json:async()=>({rev:3})};};
  await r.ctx.pushSync(false);assert.equal(sent.baseRev,2);assert.equal(r.ctx.state.syncBaseRev,3);
});
test('textbook analyses contain no accidentally appended chapter appendix',()=>{
  for(const f of ['bank-algebra','bank-analysis','bank-geometry','bank-western']) for(const q of JSON.parse(read('src/data/'+f+'.json')).items) {
    for(const field of ['detailedAnalysis','pitfalls']) assert.doesNotMatch(JSON.stringify(q[field]),/## (题型清单|Reference Tables|课堂重点|Key Takeaways)/,q.id);
  }
});
test('all nonempty bank template references resolve in the same subject',()=>{
  const subjects=JSON.parse(read('src/data/seed.json')).subjects;
  const files={gaodai:'algebra',shufen:'analysis',jieji:'geometry',xijing:'western'};
  for(const subject of subjects) {
    const ids=new Set(subject.templates.map(t=>t.id));
    for(const q of JSON.parse(read('src/data/bank-'+files[subject.id]+'.json')).items) if(q.templateId) assert.ok(ids.has(q.templateId),q.id+': '+q.templateId);
  }
});
test('corrected textbook least-squares solution satisfies the unrounded normal equations',()=>{
  const a=[.39,.61,.93,1.35],b=[-1.89,-1.80,-1.68,-1.50];
  const u=a.reduce((s,v)=>s+v*v,0),v=a.reduce((s,x,i)=>s+x*b[i],0),w=b.reduce((s,y)=>s+y*y,0);
  const c=a.reduce((s,x)=>s+x,0),d=b.reduce((s,y)=>s+y,0);const determinant=u*w-v*v;
  assert.ok(Math.abs(determinant-8.76475395)<1e-10);
  const x=(c*w-v*d)/determinant,y=(u*d-v*c)/determinant;
  assert.ok(Math.abs(x-.19722002578292572)<1e-10);assert.ok(Math.abs(y+.48807896084749763)<1e-10);
  const q=JSON.parse(read('src/data/bank-algebra.json')).items.find(q=>q.id==='GA-TX043');
  assert.match(q.standardSolution,/8\.76475395/);assert.match(q.answer,/0\.197/);
});
test('startup sync never silently replaces unsynced local changes with newer remote data',async()=>{
  const r=runtime(JSON.stringify(savedState()));r.run('05-sync.js');r.ctx.PAGES=false;
  r.ctx.state.syncDirty=true;r.ctx.state.syncBaseRev=2;r.ctx.state.updatedAt='2026-01-01T00:00:00Z';
  r.ctx.renderSyncStatus=()=>{};r.ctx.fetch=async url=>({ok:true,status:200,json:async()=>({rev:3,state:{...savedState(),updatedAt:'2026-12-01T00:00:00Z'}})});
  await r.ctx.initSync();assert.equal(r.ctx.state.updatedAt,'2026-01-01T00:00:00Z');assert.equal(r.ctx.sync.mode,'conflict');
});
test('manual pull asks before replacing local changes; background pull preserves them',async()=>{
  const r=runtime();r.run('05-sync.js');r.ctx.sync.available=true;r.ctx.state.syncDirty=true;
  r.ctx.state.entries.gaodai=[savedEntry()];r.ctx.renderSyncStatus=()=>{};let confirm=false;
  r.ctx.confirmDialog=()=>{confirm=true;};r.ctx.fetch=async()=>({ok:true,status:200,json:async()=>({rev:4,state:{...savedState(),updatedAt:'2026-12-01'}})});
  await r.ctx.pullSync(false);assert.equal(confirm,false);assert.equal(r.ctx.sync.mode,'conflict');
  await r.ctx.pullSync(true);assert.equal(confirm,true);assert.equal(r.ctx.state.entries.gaodai[0].id,'keep');
});
