/* =========================================================
   03-sync — self-hosted JSON sync (optional)
   ========================================================= */
function apiHeaders(extra) {
  var h = { 'Accept': 'application/json' };
  if (sync.token) h['X-Notebook-Token'] = sync.token;
  if (extra) Object.keys(extra).forEach(function (k) { h[k] = extra[k]; });
  return h;
}

function setSyncState(mode, detail) {
  sync.mode = mode;
  sync.online = mode === 'online';
  if (detail) sync.detail = detail;
  renderSyncStatus();
}

async function initSync() {
  if (PAGES) {
    setSyncState('local', 'GitHub Pages 静态版 · 本机保存');
    return;
  }
  if (!/^https?:$/.test(location.protocol)) {
    setSyncState('local', '文件打开 · 本机保存');
    return;
  }
  try {
    var health = await fetch('/api/health', { headers: apiHeaders(), cache: 'no-store' });
    if (!health.ok) throw new Error('no api');
    sync.available = true;
    var res = await fetch('/api/state', { headers: apiHeaders(), cache: 'no-store' });
    if (res.status === 401) {
      setSyncState('locked', '需要访问口令');
      if (typeof render === 'function') render();
      return;
    }
    if (!res.ok) throw new Error('bad state');
    var remote = await res.json();
    if (remote && remote.state && remote.state.entries) {
      var localTime = new Date(state.updatedAt).getTime();
      var remoteTime = new Date(remote.state.updatedAt || 0).getTime();
      if (isFreshLocal) {
        adoptRemote(remote, false);
        toast('已载入云端最新版本');
      } else if (remoteTime > localTime && (state.rev || 0) <= (remote.rev || 0)) {
        adoptRemote(remote, false);
        toast('已载入云端最新版本');
      } else if (remoteTime === localTime && (remote.rev || 0) > (state.rev || 0)) {
        state.rev = remote.rev;
        persistLocal();
      } else if ((state.rev || 0) > (remote.rev || 0)) {
        schedulePush(50);
      }
    } else {
      schedulePush(50);
    }
    sync.lastSync = remote && remote.updatedAt;
    setSyncState('online', remote && remote.rev != null ? ('rev ' + remote.rev) : '');
    if (subjectMigrationPending) { subjectMigrationPending = false; schedulePush(1000); }
  } catch (e) {
    sync.available = false;
    setSyncState('local', '未连接同步服务');
  }
  renderSyncStatus();
}

function adoptRemote(remote, skipRender) {
  if (!remote || !remote.state) return;
  var st = migrateState(remote.state);
  st.rev = remote.rev || st.rev || 0;
  st.updatedAt = remote.updatedAt || st.updatedAt;
  var theme = state.prefs ? state.prefs.theme : 'auto';
  state = st;
  isFreshLocal = false;
  state.prefs = state.prefs || {};
  state.prefs.theme = theme;
  var migratedKeys = subjectMigrationPending;
  persistLocal();
  if (migratedKeys) schedulePush(1000);
  applyTheme();
  if (!skipRender && typeof render === 'function') render();
}

var pushTimer = null;
function schedulePush(delay) {
  if (!sync.available) return;
  clearTimeout(pushTimer);
  pushTimer = setTimeout(function () { pushSync(false); }, delay == null ? 900 : delay);
}

async function pushSync(manual) {
  if (!sync.available) {
    if (manual) toast('当前没有连接同步服务，数据只在本机');
    return;
  }
  if (sync.busy) { sync.pending = true; return; }
  sync.busy = true;
  renderSyncStatus();
  try {
    var attempts = 0;
    while (attempts < 3) {
      attempts++;
      var body = JSON.stringify({ baseRev: state.rev || 0, state: state });
      var res = await fetch('/api/state', {
        method: 'PUT',
        headers: apiHeaders({ 'Content-Type': 'application/json' }),
        body: body
      });
      if (res.status === 409) {
        var cur = await res.json();
        var remoteTime = new Date((cur.state && cur.state.updatedAt) || 0).getTime();
        var localTime = new Date(state.updatedAt).getTime();
        if (cur.state && remoteTime > localTime + 1500) {
          adoptRemote(cur, false);
          toast('云端有更新的改动，已载入');
          break;
        }
        state.rev = cur.rev || state.rev;
        continue;
      }
      if (res.status === 401) {
        setSyncState('locked', '需要访问口令');
        toast('同步服务需要访问口令，请在设置里填写');
        break;
      }
      if (!res.ok) throw new Error('push failed');
      var data = await res.json();
      state.rev = data.rev;
      state.updatedAt = data.updatedAt || state.updatedAt;
      persistLocal();
      sync.lastSync = data.updatedAt;
      setSyncState('online', 'rev ' + data.rev);
      if (manual) toast('已同步到云端 · rev ' + data.rev);
      break;
    }
  } catch (e) {
    setSyncState('offline', '同步失败，稍后重试');
    if (manual) toast('同步失败：' + (e.message || e));
  } finally {
    sync.busy = false;
    renderSyncStatus();
    if (sync.pending) { sync.pending = false; schedulePush(150); }
  }
}

async function pullSync(manual) {
  if (!sync.available) {
    if (manual) toast('未连接同步服务');
    return;
  }
  try {
    var res = await fetch('/api/state', { headers: apiHeaders(), cache: 'no-store' });
    if (res.status === 401) { setSyncState('locked', '需要访问口令'); return; }
    if (!res.ok) throw new Error('pull failed');
    var remote = await res.json();
    if (!remote.state || !remote.state.entries) { if (manual) toast('云端还没有数据'); return; }
    var localTime = new Date(state.updatedAt).getTime();
    var remoteTime = new Date(remote.state.updatedAt || 0).getTime();
    if ((isFreshLocal && !(state.rev || 0)) || remoteTime > localTime) {
      adoptRemote(remote, false);
      toast('已拉取云端最新版本');
    } else if (manual) {
      toast('云端没有比本地更新的版本');
    }
    sync.lastSync = remote.updatedAt;
    setSyncState('online', 'rev ' + remote.rev);
  } catch (e) {
    setSyncState('offline', '拉取失败');
    if (manual) toast('拉取失败');
  }
}

function renderSyncStatus() {
  var text = sync.available
    ? (sync.online ? '云端同步 · ' + (sync.lastSync ? timeAgo(sync.lastSync) : '已连接') : (sync.mode === 'locked' ? '需要口令' : '未连接'))
    : '本机保存';
  if (sync.busy) text = '同步中…';
  qsa('[data-sync-text]').forEach(function (el) { el.textContent = text; });
  qsa('[data-sync-dot]').forEach(function (d) {
    d.className = 'sync-dot' + (sync.busy ? '' : sync.online ? ' ok' : sync.available ? ' err' : '');
  });
}
