'use strict';
const { chromium } = require('playwright-core');
const path = require('path');
(async function () {
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const out = { errors: [] };
  const base = 'http://127.0.0.1:4173/';
  const shots = path.join(__dirname, '..', 'screenshots');
  async function mk(vp) {
    const ctx = await browser.newContext({ viewport: vp, isMobile: vp.width < 500, hasTouch: vp.width < 500, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    page.on('pageerror', function (e) { out.errors.push('pageerror: ' + e.message); });
    page.on('console', function (m) { if (m.type() === 'error' && m.text().indexOf('409') < 0) out.errors.push('console: ' + m.text()); });
    await page.goto(base, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1000);
    return page;
  }
  const page = await mk({ width: 1440, height: 1000 });

  // gaodai bank with math
  await page.locator('[data-act="nav-view"][data-view="bank"]').first().click();
  await page.waitForTimeout(500);
  out.gaodaiBank = await page.locator('.bank-item').count();
  await page.locator('[data-act="toggle-bank-answer"]').first().click();
  await page.waitForTimeout(500);
  out.bankMath = await page.locator('.bank-item math').count();
  out.bankRaw = await page.locator('.bank-item .math-raw').count();
  await page.screenshot({ path: path.join(shots, 'bank-algebra.png'), fullPage: false });

  // shufen entry
  await page.locator('[data-act="nav-subject"][data-subject="shufen"]').first().click();
  await page.waitForTimeout(500);
  await page.locator('[data-act="nav-view"][data-view="overview"]').first().click();
  await page.waitForTimeout(500);
  out.shufenHero = await page.locator('.hero-title').textContent();
  await page.locator('[data-act="nav-view"][data-view="entries"]').first().click();
  await page.waitForTimeout(400);
  out.shufenEntries = await page.locator('.entry').count();
  await page.locator('.entry-head').first().click();
  await page.waitForTimeout(600);
  out.shufenBlocks = await page.locator('.entry-body .block').count();
  out.shufenMath = await page.locator('.entry-body math').count();
  await page.screenshot({ path: path.join(shots, 'entry-analysis.png'), fullPage: true });

  // jieji bank
  await page.locator('[data-act="nav-subject"][data-subject="jieji"]').first().click();
  await page.waitForTimeout(500);
  await page.locator('[data-act="nav-view"][data-view="bank"]').first().click();
  await page.waitForTimeout(500);
  out.jiejiBank = await page.locator('.bank-item').count();
  await page.locator('[data-act="toggle-bank-answer"]').nth(1).click();
  await page.waitForTimeout(500);
  out.jiejiMath = await page.locator('.bank-item math').count();
  await page.screenshot({ path: path.join(shots, 'bank-geometry.png'), fullPage: false });

  // editor save test on gaodai entry
  await page.locator('[data-act="nav-subject"][data-subject="gaodai"]').first().click();
  await page.waitForTimeout(400);
  await page.locator('[data-act="nav-view"][data-view="entries"]').first().click();
  await page.waitForTimeout(400);
  await page.locator('.entry-head').first().click();
  await page.waitForTimeout(400);
  await page.locator('[data-act="edit-entry"]').first().click();
  await page.waitForTimeout(500);
  out.editorFormPoints = await page.locator('#f-points').inputValue();
  await page.locator('#f-points').fill('测试要点A；测试要点B');
  await page.locator('#f-source').fill('QA 编辑测试');
  await page.locator('[data-act="save-entry"]').click();
  await page.waitForTimeout(1200);
  out.savedOpenEntry = await page.locator('.entry.is-open .entry-title').first().textContent();
  out.savedPoints = await page.locator('.entry.is-open .chip').first().textContent();
  out.savedSource = await page.locator('.entry.is-open .entry-meta').first().textContent();
  await page.screenshot({ path: path.join(shots, 'entry-edited.png'), fullPage: false });

  // add entry test
  await page.locator('[data-act="add-entry"]').first().click();
  await page.waitForTimeout(500);
  await page.locator('#f-code').fill('QA-TEST-1');
  await page.locator('#f-points').fill('QA 新条目');
  await page.locator('#blockEditors .b-md').first().fill('已知测试题面，证明 $a^2+b^2 \\ge 2ab$。');
  await page.locator('[data-act="save-entry"]').click();
  await page.waitForTimeout(1200);
  out.entryCountAfterAdd = await page.locator('.entry').count();
  out.addedEntryExists = await page.locator('.entry-code').filter({ hasText: 'QA-TEST-1' }).count();
  // cleanup: delete test entry
  await page.locator('[data-act="delete-entry"]').first().click();
  await page.waitForTimeout(400);
  await page.locator('#confirmOk').click();
  await page.waitForTimeout(800);
  out.entryCountAfterDelete = await page.locator('.entry').count();

  // mobile
  const mp = await mk({ width: 390, height: 844 });
  out.mobile = await mp.evaluate(function () {
    return { scrollW: document.documentElement.scrollWidth, innerW: window.innerWidth };
  });
  await mp.screenshot({ path: path.join(shots, 'mobile-overview.png'), fullPage: true });
  await mp.locator('[data-act="nav-view"][data-view="entries"]').first().click();
  await mp.waitForTimeout(400);
  await mp.locator('.entry-head').first().click();
  await mp.waitForTimeout(500);
  await mp.screenshot({ path: path.join(shots, 'mobile-entry.png'), fullPage: true });
  await mp.locator('.top-actions [data-act="open-settings"]').first().click();
  await mp.waitForTimeout(400);
  await mp.screenshot({ path: path.join(shots, 'mobile-settings.png'), fullPage: false });

  console.log(JSON.stringify(out, null, 2));
  await browser.close();
})().catch(function (e) { console.error('QA2 FAILED:', e && e.stack || e); process.exit(1); });
