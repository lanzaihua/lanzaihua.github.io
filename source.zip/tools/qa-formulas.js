'use strict';
const { chromium } = require('playwright-core');
const { spawn } = require('node:child_process');
const path = require('node:path');

(async () => {
  const server = spawn('python', ['-m', 'http.server', '4450'], {
    cwd: path.join(__dirname, '..', 'dist-pages'),
    stdio: 'ignore'
  });
  await new Promise(r => setTimeout(r, 800));
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const page = await (await browser.newContext({ viewport: { width: 1200, height: 1000 } })).newPage();
  const failures = [];
  try {
    await page.goto('http://127.0.0.1:4450/?v=' + Date.now() + '#/home', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(500);
    await page.evaluate(() => {
      const key = 'sanke-cuotiben-v1';
      const st = JSON.parse(localStorage.getItem(key) || '{}');
      if (!st.entries) st.entries = {};
      if (!st.entries.gaodai) st.entries.gaodai = [];
      st.entries.gaodai.push({
        id: 'qa-formula',
        code: 'A-999',
        date: '2026-10-30T11:28:00.000Z',
        summary: 'Matrix $\\begin{pmatrix}$0&1\\\\0&0$\\end{pmatrix}$ and rank $r(A)$',
        points: ['Rank $r(A)$', 'Eigenvalue $\\lambda$'],
        chapter: '第三章 线性方程组',
        templateId: '',
        stars: 2,
        status: 'unmastered',
        blocks: [{ title: '题目', md: 'Find $n$-th power of $2\\times 2$ matrix' }],
        variants: [],
        review: { d1: false, d3: false, d7: false, d15: false, d30: false },
        source: '智能录入 · /advanced-algebra'
      });
      localStorage.setItem(key, JSON.stringify(st));
    });
    const routes = ['overview', 'entries', 'templates', 'bank', 'guide'];
    for (const r of routes) {
      await page.goto('http://127.0.0.1:4450/?v=' + Date.now() + '#/gaodai/' + r, { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(650);
      const out = await page.evaluate(() => {
        const raw = [];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {
          const n = walker.currentNode;
          const t = n.nodeValue || '';
          if (!/\$[^$\n]+\$/.test(t)) continue;
          const par = n.parentElement;
          if (!par || par.closest('code,pre,textarea,script,style,.math-raw,.source-code,.md-copy')) continue;
          raw.push(t.slice(0, 80));
        }
        return { raw, broken: document.querySelectorAll('.temml-error,.math-raw').length };
      });
      if (out.raw.length) failures.push(r + ' raw formula: ' + out.raw[0]);
      if (out.broken) failures.push(r + ' broken formula: ' + out.broken);
      console.log(r, JSON.stringify(out));
    }
  } finally {
    await browser.close();
    server.kill();
  }
  if (failures.length) {
    console.error('FAIL\n' + failures.join('\n'));
    process.exit(1);
  }
  console.log('formula QA passed');
})();
