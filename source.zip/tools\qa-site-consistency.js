'use strict';
/* Cross-page consistency gate: counts, dates, stale copy and skill links. */
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src');
const problems = [];
const read = (p) => fs.readFileSync(p, 'utf8');

function add(cond, msg) { if (cond) problems.push(msg); }

const banks = ['bank-algebra.json', 'bank-analysis.json', 'bank-geometry.json', 'bank-western.json']
  .map((f) => JSON.parse(read(path.join(SRC, 'data', f))));
const totals = banks.map((b) => (b.items || []).length);
add(totals.join(',') !== '1500,3450,900,2400', '四科题库计数不一致：' + totals.join(' / '));
add(totals.reduce((a, b) => a + b, 0) !== 8250, '题库总数不是 8250');

const jsFiles = fs.readdirSync(path.join(SRC, 'js')).filter((f) => /\.js$/.test(f));
const js = jsFiles.map((f) => read(path.join(SRC, 'js', f))).join('\n');
const allSource = js + '\n' + read(path.join(SRC, 'index.template.html')) + '\n' + read(path.join(SRC, 'styles.css'));
add(/901\s*题|题库\s*901|解几\s*901/.test(allSource), '页面仍含解析几何 901 的旧计数');
add(/8251/.test(allSource), '页面仍含 8251 的旧计数');
add(/92\s*道/.test(allSource), '页面仍含 92 道旧计数');
add(/<b>A<\/b>高代|<b>M<\/b>数分|<b>G<\/b>解几|<b>E<\/b>西经/.test(js), '规范页仍用 A/M/G/E 旧编号');
add(/仅本机保存<\/span><\/span>\s*·\s*数据保存在浏览器与自建服务里/.test(js), '页脚仍把“仅本机保存”和“自建服务”并列');
add(/从空白开始/.test(js), '首页仍有“从空白开始”旧文案');

const changelog = read(path.join(SRC, 'js', '48-changelog.js'));
const dates = Array.from(changelog.matchAll(/^\s{4}date: '([^']+)'/gm)).map((m) => m[1]);
add(new Set(dates).size !== dates.length, '更新记录存在重复日期');
const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai' }).format(new Date());
dates.forEach((d) => add(d > today, '更新记录日期晚于今天：' + d));
add(!dates.includes('2026-11-03'), '缺少 2026-11-03 更新记录');
add(!changelog.includes("title: '题库方案'"), '11-03 未改为题库方案，可能与 11-04 重建冲突');
add(!changelog.includes("title: '题库与界面'"), '缺少 11-04 题库重建记录');

const readme = read(path.join(ROOT, '导出', 'GitHub-README.md'));
add(/901/.test(readme), '仓库 README 仍含解析几何 901');
add(/8251/.test(readme), '仓库 README 仍含 8251');
add(/92\s*道/.test(readme), '仓库 README 仍含 92 道');
add(!readme.includes('3554833568@qq.com'), '仓库 README 缺少邮箱');
add(!readme.includes('### 2026-11-05 · 技能、公式与开源'), '仓库 README 最新更新标题不一致');
const latestBlock = readme.slice(readme.indexOf('### 2026-11-05'), readme.indexOf('### 2026-11-04'));
const latestCount = latestBlock.match(/\*\*(\d+) 项 · (\d+) 组\*\*/);
const latestRows = (latestBlock.match(/^\| \*\*/gm) || []).length;
add(!latestCount || Number(latestCount[1]) !== latestRows, '仓库 README 最新更新计数与分组行不一致');
const badgeColors = Array.from(readme.matchAll(/img\.shields\.io\/badge\/[^"?]*-([0-9A-Fa-f]{6})\?/g)).map((m) => m[1].toUpperCase());
add(badgeColors.length !== 9, '仓库徽章不是 9 个');
add(new Set(badgeColors).size !== badgeColors.length, '仓库徽章颜色有重复：' + badgeColors.join(','));

['advanced-algebra', 'mathematical-analysis', 'analytic-geometry', 'western-economics'].forEach((s) => {
  add(!fs.existsSync(path.join(ROOT, 'skills', s, 'SKILL.md')), '缺少开源 skill：skills/' + s);
});
add(fs.existsSync(path.join(ROOT, 'skills', 'design-taste-frontend')), '仓库不应包含未授权第三方 skill：design-taste-frontend');

if (problems.length) {
  console.error(JSON.stringify({ ok: false, problems }, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, totals, dates: dates.length }, null, 2));
