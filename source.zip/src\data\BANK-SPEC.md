# 题库 JSON 规范（举一反三）

本文件规定三个科目的题库文件格式。每个文件独立，由对应的 bank 作者写入。

## 输出文件

| 科目 | 文件 | 技能目录 |
|---|---|---|
| 高等代数 | `src/data/bank-algebra.json` | `C:\Users\廖子恒\.agents\skills\advanced-algebra` |
| 数学分析 | `src/data/bank-analysis.json` | `C:\Users\廖子恒\.agents\skills\mathematical-analysis` |
| 解析几何 | `src/data/bank-geometry.json` | `C:\Users\廖子恒\.agents\skills\analytic-geometry` |
| 西方经济学 | `src/data/bank-western.json` | `C:\Users\廖子恒\.agents\skills\western-economics` |

项目根目录：`D:\学习\大一\错题本网页`

## 顶层结构

```json
{
  "subject": "gaodai",
  "generatedAt": "2026-10-22T00:00:00+08:00",
  "items": [ ... ]
}
```

`subject` 取值：`gaodai` / `shufen` / `jieji` / `xijing`（与 seed.json 中一致）。

## 单题结构

```json
{
  "id": "GA-B01",
  "subject": "gaodai",
  "chapter": "第三章 线性方程组",
  "templateId": "T-03-05",
  "pointKeys": ["极大线性无关组与秩"],
  "title": "秩为 r 的向量组中，任意 r 个无关向量是否极大",
  "question": "设向量组 $\\alpha_1,\\dots,\\alpha_s$ 的秩为 $r$。证明：……",
  "answer": "$\\alpha_{i_1},\\dots,\\alpha_{i_r}$ 是极大线性无关组。",
  "solution": [
    "取整组的一个 $r$ 元极大无关组，说明整组可由它表出。",
    "反设给定 $r$ 元组还能添入向量，得 $r+1$ 个无关向量由 $r$ 个表出，与推论 1 矛盾。"
  ],
  "difficulty": 2,
  "tags": ["证明", "秩", "反证"],
  "source": "自拟变式（模板 T-03-05）",
  "relatedEntries": ["001"]
}
```

## 字段约束

- `id`：高代 `GA-B01`…，数分 `MA-B01`…，解几 `GE-B01`…，西经 `WE-B01`…，两位序号，全局唯一。
- `chapter`：必须与 `src/data/seed.json` 中该科已出现的章节名一致；模板章节可在 `模板sections` 里查到。解几用技能章节名（如「第三章 平面与空间直线」）。
- `templateId`：存在于该科 `seed.json.templates` 的编号；解几是 `T01`、`T02`…；若确属新题型，写 `T99` 并在 `source` 注明「新题型」。
- `pointKeys`：1–3 个知识要点短语，尽量与 seed 条目里的 `points` / 模板标题用同一措辞，便于「举一反三」匹配。
- `question` / `answer`：完整可做题面与最终答案。数学用 LaTeX：行内 `$...$`，独立 `$$...$$`；**JSON 中反斜杠必须双写**（`\\\\alpha` → 文件里 `\\alpha`）。中文标点可用。
- `solution`：2–5 条解题要点/关键步骤，不必写完整卷面解答；要能直接帮学生「想起来」。
- `difficulty`：1 基础 / 2 常规 / 3 综合。
- `tags`：2–4 个关键词（方法、题型、易错点）。
- `source`：`自拟变式（模板 T-xx）` 或 `教材同型题（第X章）`。**不要编造页码、年份、考试名**。
- `relatedEntries`：该题对应 seed 条目的 `code`（如 `"A-001"`、`"M-001"`）；没有就给空数组。

## 数量与覆盖

每个科目 **20–25 题**（扩充后：高代 20、数分 25、解几 22、西经 25），其中：

- 高代：至少覆盖 T-03-05、T-03-06、T-03-07（现有条目模板），再选 6–8 个高价值模板（建议 T-02-03/T-02-04 行列式、T-04-01 求逆、T-04-05 秩不等式、T-05-04 正定、T-07-02 对角化、T-09-01 施密特），最后 1 题综合。
- 数分：覆盖 T-04（现有条目），再选 T-01、T-05、T-07、T-08、T-10、T-12、T-13 中的 7–9 个，最后 1 题综合。
- 解几：T01 共面 3 题；平面与直线 2 题；二次曲面 2 题；二次曲线 2 题；轨迹/坐标变换 2 题；综合 1 题。

每题必须自洽、可判对错；答案与题面数字要对得上。宁可少一题，不要出错。

## 校验

写完运行：

```powershell
node -e "const j=require('./src/data/bank-algebra.json'); console.log(j.items.length, j.items.map(i=>i.id).join(','))"
```

（换成对应文件）确认 JSON 合法、条数正确、id 无重复。
